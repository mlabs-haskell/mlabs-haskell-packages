module PPrelude (
  module Prelude,
  module Plutarch.Prelude,
) where

import Plutarch.Prelude
import Prelude
